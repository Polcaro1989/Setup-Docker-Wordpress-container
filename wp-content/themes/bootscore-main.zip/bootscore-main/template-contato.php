<?php
/*
Template Name: Pagina de Contato
*/


// Incluir o arquivo do card pricing
get_template_part('patterns/cards-pricing');

// Adicionar outros componentes, como formul  rios de contato ou conte  do adicional
?>

<div class="container">
    <h1>Entre em Contato</h1>
    <!-- Outros componentes da p  gina de contato -->
</div>

