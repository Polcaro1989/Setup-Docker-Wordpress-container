<?php
/**
 * Title: btn-outline-secondary-sm
 * Slug: bootscore/btn-outline-secondary-sm
 * Categories: bootscore
 * https://developer.wordpress.org/themes/features/block-patterns/
 * 
 * @package Bootscore
 * @version 6.0.0
 */

// Exit if accessed directly
defined('ABSPATH') || exit;

?>
<!-- wp:paragraph {"metadata":{"name":"btn-outline-secondary-sm"}} -->
<p><a class="btn btn-outline-secondary btn-sm" href="#">Button</a></p>
<!-- /wp:paragraph -->