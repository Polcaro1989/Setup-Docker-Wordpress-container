<?php
/**
 * Title: btn-danger-lg
 * Slug: bootscore/btn-danger-lg
 * Categories: bootscore
 * https://developer.wordpress.org/themes/features/block-patterns/
 * 
 * @package Bootscore
 * @version 6.0.0
 */

// Exit if accessed directly
defined('ABSPATH') || exit;

?>
<!-- wp:paragraph {"metadata":{"name":"btn-danger-lg"}} -->
<p><a class="btn btn-danger btn-lg" href="#">Button</a></p>
<!-- /wp:paragraph -->