<?php
/**
 * Title: btn-primary
 * Slug: bootscore/btn-primary
 * Categories: bootscore
 * https://developer.wordpress.org/themes/features/block-patterns/
 * 
 * @package Bootscore
 * @version 6.0.0
 */

// Exit if accessed directly
defined('ABSPATH') || exit;

?>
<!-- wp:paragraph {"metadata":{"name":"btn-primary"}} -->
<p><a class="btn btn-primary" href="#">Button</a></p>
<!-- /wp:paragraph -->