<?php
/**
 * Title: container
 * Slug: bootscore/container
 * Categories: bootscore
 * https://developer.wordpress.org/themes/features/block-patterns/
 * 
 * @package Bootscore
 * @version 6.0.0
 */

// Exit if accessed directly
defined('ABSPATH') || exit;

?>
<!-- wp:group {"metadata":{"name":"container"},"className":"container","layout":{"type":"default"}} -->
<div class="wp-block-group container"><!-- wp:paragraph -->
<p>This is a <code>container</code></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->